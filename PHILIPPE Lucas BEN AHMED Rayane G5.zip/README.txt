README

Lancer l'application, notez votre pseudo ainsi que votre mail et mot de passe.
Une fois remplie vous pouvez appuyer sur le bouton "Sign-up".
Si vous avez déjà un compte appuyez sur le bouton "Already an account ?"
Vous passerez donc sur la page pour se connecter, remplir les champs de votre email et mot de passe.
Une fois cela fait, vous pouvez me "Sign-in".
Vous aurez le choix entre les modes vous pouvez choisir.
Une fois le mode lancée, appuyer sur le bouton start, attendre la séquence de couleur qui s'affiche et appuyer sur la/les bonne(s) couleur(s).
Si vous avez réussi la séquence, il faut appuyer sur le bouton continuer. Sinon vous avez perdu une vie et il faudra aussi appuyer sur le bouton continuer.
Si vous êtes mort, cela vous proposera de rejouer au niveau ou vous êtes.
Une fois la partie terminée, cela vous renvoie à la page de choix des modes.
Ici vous verrez le classement
