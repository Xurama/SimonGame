package com.dut2.simongame;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Connection extends AppCompatActivity {

    EditText email, pass;
    Button connect, inscription;
    SQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        email = findViewById(R.id.email);
        pass = findViewById(R.id.pass);
        connect = findViewById(R.id.connect);
        inscription = findViewById(R.id.inscription);
        db = new SQLiteHelper(getApplicationContext());

        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().equals("") && pass.getText().toString().equals(""))
                {
                    Toast.makeText(Connection.this, "Login ou Password incorrect", Toast.LENGTH_SHORT).show();
                }
                else{
                Intent intent = new Intent(Connection.this, Mode.class);
                startActivity(intent);
                }
            }
        });

        inscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Connection.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
