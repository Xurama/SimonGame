package com.dut2.simongame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class GameActivity extends AppCompatActivity {
    List<Button> buttonsList = new ArrayList<>();
    List<Button> combination = new ArrayList<>();
    List<Button> sequenceButtons = new ArrayList<>();
    Button buttonStart;
    CountDownTimer chronometre;
    long tempsSecondes = 0;
    int position = 0;
    int nb_bloc_debut;
    int nb_bloc_victoire;
    int nb_bloc_initial;
    int vies_initial;
    int vies;
    int counter;
    int nbTour = 1;
    int nb_bloc_eclaire;
    double nb_bloc_debut_initial;
    int level;
    double score;
    double poids;
    boolean chrono;
    boolean vivant = true;
    boolean combinationOver;
    TextView textViewScore;
    TextView textViewVie;
    TextView textViewTour;
    TextView textViewTemps;
    TextView textViewLevel;
    SQLiteHelper db;

    int[] arrayColorLight = {
            R.color.redLight,
            R.color.blueLight,
            R.color.greenLight,
            R.color.yellowLight,
            R.color.orangeLight,
            R.color.purpleLight,
            R.color.tealLight,
            R.color.blackLight,
            R.color.pinkLight,
            R.color.brownLight
    };

    int[] arrayColor = {
            R.color.red,
            R.color.blue,
            R.color.green,
            R.color.yellow,
            R.color.orange,
            R.color.purple,
            R.color.teal,
            R.color.black,
            R.color.pink,
            R.color.brown
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);


        textViewScore = findViewById(R.id.textViewScore);
        textViewVie= findViewById(R.id.textViewVie);
        textViewTour = findViewById(R.id.textViewTour);
        textViewTemps = findViewById(R.id.textViewTemps);
        textViewLevel = findViewById(R.id.textViewLevel);
        textViewLevel.setText(getString(R.string.level) + level);
        Log.e("score", String.valueOf(score));


        textViewLevel.setVisibility(View.INVISIBLE);
        textViewScore.setVisibility(View.INVISIBLE);
        textViewTour.setVisibility(View.INVISIBLE);
        textViewVie.setVisibility(View.INVISIBLE);
        //création d'un tableau de bouton pour pouvoir vérifier la séquence du joueur

        buttonsList.add(findViewById(R.id.buttonColorRed));
        buttonsList.add(findViewById(R.id.buttonColorBlue));
        buttonsList.add(findViewById(R.id.buttonColorGreen));
        buttonsList.add(findViewById(R.id.buttonColorYellow));
        buttonsList.add(findViewById(R.id.buttonColorOrange));
        buttonsList.add(findViewById(R.id.buttonColorPurple));
        buttonsList.add(findViewById(R.id.buttonColorTeal));
        buttonsList.add(findViewById(R.id.buttonColorBlack));
        buttonsList.add(findViewById(R.id.buttonColorPink));
        buttonsList.add(findViewById(R.id.buttonColorBrown));
        buttonStart = findViewById(R.id.buttonCommencer);

        Bundle choixMode = getIntent().getExtras();
        if(choixMode != null)
        {
            nb_bloc_debut = choixMode.getInt("nb_bloc_start");
            nb_bloc_victoire = choixMode.getInt("nb_bloc_win");
            nb_bloc_eclaire = choixMode.getInt("nb_bloc_eclaire");
            vies = choixMode.getInt("vies", 2);
            poids = choixMode.getDouble("poids");
            level = choixMode.getInt("level", 1);
            score = choixMode.getDouble("score", 0);
            chrono = choixMode.getBoolean("chrono", false);
            nb_bloc_initial = nb_bloc_eclaire;
            vies_initial = vies;
        }





        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonStart.setBackgroundColor(buttonStart.getContext().getResources().getColor(R.color.gray,getTheme()));
                for(int i=0;i < nb_bloc_debut;i++){
                    buttonsList.get(i).setVisibility(View.VISIBLE);
                }
                if (chrono) {
                    findViewById(R.id.textViewTemps).setVisibility(View.VISIBLE);
                }
                textViewLevel.setVisibility(View.VISIBLE);
                textViewScore.setVisibility(View.VISIBLE);
                textViewTour.setVisibility(View.VISIBLE);
                textViewVie.setVisibility(View.VISIBLE);
                textViewScore.setText("Score :"+score);
                textViewLevel.setText("Level : "+level);
                textViewTour.setText("Tour :"+nbTour);
                textViewVie.setText("Vies : "+vies);
                WriteSequence(buttonsList);

                if(level == 7 && nbTour == nb_bloc_victoire){
                    Intent intent = new Intent(GameActivity.this, Mode.class);
                    startActivity(intent);
                    db.addScore((int) score);
                }
            }


        });
        Thread thread = new Thread(){
            public void run(){

            }
        };

        thread.start();




    }

    public void Click(View v){
            if ((Button) v == combination.get(position)) {
                System.out.println("Bonne couleur");
                position++;
                if (position >= combination.size()) {
                    position = 0;
                    if (nbTour < nb_bloc_victoire) {
                        System.out.println("nbtour < nb_bloc_victoire");
                        buttonStart.setEnabled(true);
                        System.out.println("Click");
                        Toast.makeText(GameActivity.this, "Appuyez sur continuer pour passer au tour suivant", Toast.LENGTH_SHORT).show();
                        buttonStart.getContext().getResources().getColor(R.color.purple,getTheme());
                        buttonStart.setText("Continuer");
                        nbTour++;
                        nb_bloc_eclaire++;
                    }else{
                        if(level == 7 && nbTour == nb_bloc_victoire)
                        {
                            System.out.println("Victoire");
                            Toast.makeText(GameActivity.this, "Vous avez gagné !", Toast.LENGTH_SHORT).show();
                            buttonStart.setText("Revenir au menu");
                            combination.clear();
                            nb_bloc_eclaire = nb_bloc_initial;
                            nbTour = 1;
                            level = 1;
                            vies = vies_initial;


                        }else{
                            System.out.println("nbtour = nb_bloc_victoire");
                            Toast.makeText(GameActivity.this, "Appuyez sur continuer pour passer au level suivant", Toast.LENGTH_SHORT).show();
                            buttonStart.setText("Level suivant");
                            score += level *poids;
                            System.out.println(score);
                            nbTour = 1;
                            combination.clear();
                            nb_bloc_eclaire = nb_bloc_initial;
                            level++;
                            nb_bloc_debut = level + 3;
                            textViewScore.setText("Score : "+score);
                        }
                    }
                }
            } else {
                if (chrono) {
                    //arrêter le temps
                }
                vies--;
                textViewVie.setText("Vies : " + vies);
                if (vies == 0) {
                    finPartie();
                    reset();
                }
                }
        }


    private void reset() {
        for(Button myButton: this.sequenceButtons)
        {
            myButton.setVisibility(View.VISIBLE);
        }
            buttonStart.setText("Rejouer");
            buttonStart.setEnabled(true);
            buttonStart.setBackgroundColor(Color.GRAY);
            buttonStart.setTextColor(Color.BLACK);
            textViewTour.setText("Tour : "+nbTour);
            textViewScore.setText("Score :"+score);
            vies = vies_initial;
            textViewVie.setText("Vies : "+score);
            combination.clear();
    }

    private void finPartie() {
        System.out.println("Echec");
        vivant = false;
        for(Button myButton: sequenceButtons)
        {
            myButton.setVisibility(View.INVISIBLE);
        }
        if(chrono)
        {
            textViewTemps.setVisibility(View.INVISIBLE);
        }
        textViewTour.setVisibility(View.INVISIBLE);
        textViewVie.setVisibility(View.INVISIBLE);
        textViewLevel.setVisibility(View.INVISIBLE);
        buttonStart.setBackgroundColor(Color.BLACK);
        buttonStart.setTextColor(Color.WHITE);
        buttonStart.setText("Vous avez perdu !");
    }

    public void etatBouton(boolean state){
        for (Button button : sequenceButtons) {
            button.setEnabled(state);
        }
    }

    public void WriteSequence(List<Button> buttonList) {
        Random random = new Random();
        Button randButton;
        sequenceButtons.clear();
        if(chrono) {
            Log.i("Chrono :", "on");
            tempsSecondes = nb_bloc_debut*2*1000+1000;
            startChrono();
        }
        for(int i=0;i < nb_bloc_debut;i++){
            sequenceButtons.add(buttonList.get(i));
        }
        for (int i=combination.size();i < nb_bloc_eclaire;i++) {
            randButton = sequenceButtons.get(random.nextInt(sequenceButtons.size()));
            combination.add(randButton);
        }
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(this,1000);
                for(int i=0;i < nb_bloc_debut;i++){
                    if(combination.get(counter) == sequenceButtons.get(i)){
                        combination.get(counter).setBackgroundColor(sequenceButtons.get(i).getContext().getResources().getColor(arrayColorLight[i],getTheme()));
                    }
                }
                ResetColors(combination.get(counter),500);
                counter++;
                if (counter >= nb_bloc_eclaire) {
                    combinationOver = true;
                    counter = 0;
                    handler.removeCallbacksAndMessages(null);
                }
            }
        }, 1000);
    }

    private void startChrono() {
        chronometre = new CountDownTimer(tempsSecondes,100) {
            @Override
            public void onTick(long millisUntilFinished) {
                tempsSecondes = millisUntilFinished;
                textViewTemps.setText(String.valueOf(tempsSecondes).substring(0,String.valueOf(tempsSecondes).length()-2));
            }

            @Override
            public void onFinish() {
                vies--;
                textViewVie.setText("Vies : "+vies);
                if(vies == 0)
                {
                    finPartie();
                    reset();

                }
                else{
                    reset();
                    WriteSequence(buttonsList);
                }

            }
        }.start();
    }
    
    



    public void ResetColors(Button button, int delay){ // Réinitialisation de la couleur du bouton ciblé
        final Handler handler = new Handler();
        handler.postDelayed(() -> {
            byte index = 0;
            for (Button forButton : sequenceButtons) {
                if (forButton == button)
                    button.setBackgroundColor(sequenceButtons.get(index).getContext().getResources().getColor(arrayColor[index], getTheme()));
                index++;
                System.out.println(index);
            }
        }, delay);
    }
}