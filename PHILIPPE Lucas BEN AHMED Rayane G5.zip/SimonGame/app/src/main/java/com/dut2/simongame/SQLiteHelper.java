package com.dut2.simongame;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static String BDD_NAME="GamersBDD", TABLE_NAME="Gamers", ID="id";
    public static String NAME="name", LOGIN="login", PASSWORD="password", SCORE="score";

    public SQLiteHelper(@Nullable Context context) {
        super(context, BDD_NAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        NAME + " TEXT," +
                        LOGIN + " TEXT," +
                        PASSWORD + " TEXT," +
                        SCORE + " INTEGER)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql= "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(sql);
        onCreate(db);
    }

    boolean addGamer(String name, String login, String password, int score){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues data=new ContentValues();
        data.put(NAME, name);
        data.put(LOGIN, login);
        data.put(PASSWORD, password);
        data.put(SCORE, score);

        long result = db.insert(TABLE_NAME, null, data);
        if(result != -1){
            return true;
        }
        else
            return false;
    }
    boolean connection(String login, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM Gamers WHERE login='" + login + "' AND password='" + password + "'";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            return true;
        } else
            return false;
    }
    public void addScore(int score) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(SCORE, score);

        db.insert(TABLE_NAME, null, values);

        db.close();

    }

    public String[] get5Scores() {


        String selectQuery = "SELECT  name, score FROM " + TABLE_NAME + "LIMIT 5";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        int i = 0;

        String[] data = new String[cursor.getCount()];

        while (cursor.moveToNext()) {

            data[i] = cursor.getString(1);

            i = i++;

        }
        cursor.close();
        db.close();
        return data;
    }




}
