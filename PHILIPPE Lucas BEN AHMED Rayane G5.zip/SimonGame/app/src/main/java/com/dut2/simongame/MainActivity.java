package com.dut2.simongame;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class MainActivity extends AppCompatActivity {

    EditText name, email, password;
    Button send, account;
    SQLiteHelper db;
    private SQLiteHelper GamersBDD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        db = new SQLiteHelper(getApplicationContext());

        name=findViewById(R.id.name);
        password=findViewById(R.id.password);
        email=findViewById(R.id.email);
        send=findViewById(R.id.btn_send);
        account = findViewById(R.id.btn_connect);


        //test = db.get5Scores();



        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().toString().equals(" ") | email.getText().toString().equals("")  | password.getText().toString().equals(""))
                {
                    Toast.makeText(MainActivity.this, "Erreur d'insertion", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intent = new Intent(MainActivity.this, Connection.class);
                    startActivity(intent);
                }
            }
        });

        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Connection.class);
                startActivity(intent);
            }
        });
    }

}


