package com.dut2.simongame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Mode extends AppCompatActivity {

    Button buttonFacile;
    Button buttonDifficile;
    Button buttonExpert;
    Button buttonChrono;
    Button deconnect;
    int n;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        buttonFacile = findViewById(R.id.idButtonFacile);
        buttonDifficile = findViewById(R.id.idButtonDifficile);
        buttonExpert = findViewById(R.id.idButtonExpert);
        buttonChrono = findViewById(R.id.idButtonChrono);

        buttonFacile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mode.this, "2 Vies, pas de temps de réponse et le nombre de blocs éclairés démarre de 1 jusqu`à 10", Toast.LENGTH_LONG).show();
                Intent intent =new Intent(Mode.this,GameActivity.class);
                intent.putExtra("nb_bloc_start",4);
                intent.putExtra("nb_bloc_eclaire",1);
                intent.putExtra("nb_bloc_win",10);
                intent.putExtra("vies",2);
                intent.putExtra("poids",1.0);
                startActivity(intent);
            }
        });
        buttonDifficile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mode.this, "2 vies, pas de temps de réponse et le nombre de blocs éclairés démarre de 3 jusqu'à 15", Toast.LENGTH_LONG).show();
                Intent intent =new Intent(Mode.this,GameActivity.class);
                intent.putExtra("nb_bloc_start",4);
                intent.putExtra("nb_bloc_eclaire",3);
                intent.putExtra("nb_bloc_win",15);
                intent.putExtra("vies",2);
                intent.putExtra("poids",1.5);
                startActivity(intent);
            }
        });
        buttonExpert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mode.this, "3 vies, pas de temps de réponse et le nombre de blocs éclairés démarre de 5 jusqu'à 20", Toast.LENGTH_LONG).show();
                Intent intent =new Intent(Mode.this,GameActivity.class);
                intent.putExtra("nb_bloc_start",4);
                intent.putExtra("nb_bloc_eclaire",5);
                intent.putExtra("nb_bloc_win",20);
                intent.putExtra("vies",2);
                intent.putExtra("poids",3.0);
                startActivity(intent);
            }
        });

        buttonChrono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mode.this, "3 vies, le temps de réponse est limité et le nombre de blocs éclairés démarre de 1 jusqu'à l'échec", Toast.LENGTH_LONG).show();
                Intent intent =new Intent(Mode.this,GameActivity.class);
                intent.putExtra("nb_bloc_start",4);
                intent.putExtra("nb_bloc_eclaire",1);
                intent.putExtra("nb_bloc_win",n);
                intent.putExtra("vies",3);
                intent.putExtra("poids",2);
                intent.putExtra("chrono", true);

                startActivity(intent);
            }
        });


    }
}